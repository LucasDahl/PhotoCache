//: This is a method to cahce images from Firbase in a tableview
  
import UIKit
import PlaygroundSupport

class MyViewController : UITableViewController {
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white

        let label = UILabel()
        label.frame = CGRect(x: 150, y: 200, width: 200, height: 20)
        label.text = "Hello World!"
        label.textColor = .black
        
        view.addSubview(label)
        self.view = view
        
    }
    
    //==================
    // MARK: - TableView
    //==================
    
    // Sets the row height for the tableview
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 72
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        // Return the total number of users
        return users.count
        
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // Make the cell
        let cell = tableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath) as! UserCell
        
        // Get the user
        let user = users[indexPath.row]
        
        // Set the users name
        cell.textLabel?.text = user.name
        
        // Set the users email to the dertail label
        cell.detailTextLabel?.text = user.email
        
        // Get the image url for the user
        if let profileImageUrl = user.profileImageUrl {
            cell.profileImageView.loadImageUsingCacheWithUrlString(profileImageUrl)
        }
        
        return cell
        
    }
    
}

//====================
// MARK: - Custom Cell
//====================

// Create a custom cell
class UserCell: UITableViewCell {
    
    override func layoutSubviews() {
        
        super.layoutSubviews()
        
        textLabel?.frame = CGRect(x: 64, y: textLabel!.frame.origin.y - 2, width: textLabel!.frame.width, height: textLabel!.frame.height)
        
        detailTextLabel?.frame = CGRect(x: 64, y: detailTextLabel!.frame.origin.y + 2, width: detailTextLabel!.frame.width, height: detailTextLabel!.frame.height)
    }
    
    // Default imageview
    let profileImageView: UIImageView = {
        
        // Setup the imageview
        let imageView = UIImageView()
        
        // This is needed to use the constraints
        imageView.translatesAutoresizingMaskIntoConstraints = false
        
        // Set the corner radius
        imageView.layer.cornerRadius = 24
        
        // Mask to bounds
        imageView.layer.masksToBounds = true
        
        // Set the aspect fit
        imageView.contentMode = .scaleAspectFill
        
        // Defualt image
        imageView.image = UIImage(named: "gameofthrones_splash")
        
        return imageView
        
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .subtitle, reuseIdentifier: reuseIdentifier)
        
        // Add subview
        addSubview(profileImageView)
        
        // Constraints for the imageview
        profileImageView.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 8).isActive = true
        profileImageView.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        profileImageView.widthAnchor.constraint(equalToConstant: 48).isActive = true
        profileImageView.heightAnchor.constraint(equalToConstant: 48).isActive = true
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}


// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()


// Image cache property
let imageCache = NSCache<NSString, AnyObject>()

extension UIImageView {
    
    func loadImageUsingCacheWithUrlString(_ urlString: String) {
        
        self.image = nil
        
        // Check cache for image first
        if let cachedImage = imageCache.object(forKey: urlString as NSString) as? UIImage {
            
            self.image = cachedImage
            
            return
            
        }
        
        // Otherwise fire off a new download
        let url = URL(string: urlString)
        
        URLSession.shared.dataTask(with: url!, completionHandler: { (data, response, error) in
            
            // Download hit an error
            if let error = error {
                
                print("Error getting profile Image \(error)")
                
                return
                
            }
            
            DispatchQueue.main.async(execute: {
                
                if let downloadedImage = UIImage(data: data!) {
                    
                    imageCache.setObject(downloadedImage, forKey: urlString as NSString)
                    
                    // Set the image to the downloaded image for the user profile image
                    self.image = downloadedImage
                    
                }
            })
            
        }).resume()
    }
    
}
